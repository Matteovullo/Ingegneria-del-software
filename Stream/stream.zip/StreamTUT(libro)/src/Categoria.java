public enum Categoria{
    FANTASY,
    CYBERPUNK,
    THRILLER,
    STORICO,
    INFORMATICA
}