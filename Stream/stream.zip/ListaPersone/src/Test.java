public class Test {
    public static void main (String[] args){
        ListaPersone cp = new ListaPersone();
        cp.estraiEtaPersone();
        cp.sommaEtaPersone();
        cp.trovaPersona();
        cp.trovaPersonaImper();
    }
}
